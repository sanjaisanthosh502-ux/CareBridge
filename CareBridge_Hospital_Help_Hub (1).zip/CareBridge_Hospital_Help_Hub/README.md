# CareBridge — Hospital Help Hub

A modern, responsive, beginner-friendly website concept for helping people find practical next steps for common hospital service problems.

## Features
- Responsive layout for desktop and mobile
- Six common hospital issue categories
- Search and category filters
- Modal with practical next steps for each issue
- Feedback form with character counter and validation
- Privacy reminder and emergency-care disclaimer
- Plain HTML, CSS, and JavaScript — no build tools required

## Run locally
1. Download and extract the ZIP.
2. Open `index.html` in a browser.

## Publish with GitHub Pages
1. Create a new repository on GitHub.
2. Upload `index.html`, `styles.css`, `script.js`, and `README.md` to the repository root.
3. Open **Settings → Pages**.
4. Under build/deployment, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)` folder, then save.
6. Wait for GitHub Pages to publish the site.

## Important limitations
- This is a front-end demo. Feedback is not sent to a hospital or saved to a database.
- Do not collect patient records or sensitive personal/medical information with this demo.
- For a real deployment, add a secure backend, consent and privacy notices, access controls, data retention rules, and an approved workflow for hospital staff.
- This site is not a medical diagnosis service or an emergency service. It does not replace advice from qualified healthcare professionals.
