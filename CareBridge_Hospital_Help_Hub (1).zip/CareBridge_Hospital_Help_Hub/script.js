const solutions = {
  waiting: {
    title: "Long waiting time",
    intro: "Waiting can be stressful. These steps may help you get a clearer update.",
    steps: ["Check in at the registration or reception desk and confirm that your token or appointment is recorded.", "Ask staff for an estimated wait time and whether urgent cases may affect the queue.", "If your condition becomes worse, tell a nurse or clinical staff member immediately.", "For future visits, ask whether appointments or online check-in are available."],
    tip: "Do not leave the hospital without informing staff if you are waiting for an important test result or medical review."
  },
  billing: {
    title: "Billing confusion",
    intro: "You can ask for a clear breakdown before making decisions about a bill.",
    steps: ["Request an itemised bill from the billing counter.", "Ask staff to explain any charge, deposit, or service you do not recognise.", "If you have insurance, contact the hospital insurance desk to confirm the documents and approval status.", "Keep receipts and written explanations for your records."],
    tip: "Never share bank PINs, passwords, or one-time passcodes with anyone claiming to process a hospital payment."
  },
  cleanliness: {
    title: "Cleanliness concerns",
    intro: "Report the exact location so the facilities team can respond.",
    steps: ["Tell the ward nurse, reception, or hospital help desk about the location.", "Describe the concern clearly, such as a waiting room, washroom, or spill.", "If the issue is not addressed, ask for the housekeeping supervisor or patient-relations desk.", "Avoid touching unknown waste or cleaning chemicals yourself."],
    tip: "For an immediate safety hazard, alert hospital staff directly rather than relying only on an online form."
  },
  appointment: {
    title: "Appointment difficulties",
    intro: "A few checks can help resolve booking or confirmation problems.",
    steps: ["Check the appointment date, department, and confirmation message.", "Contact the official hospital booking desk using the number on its official website or appointment slip.", "Ask whether the appointment can be rescheduled and whether any referral documents are required.", "Arrive with the confirmation and relevant documents, while keeping personal records secure."],
    tip: "If symptoms are urgent or worsening, do not wait for a routine appointment—seek timely medical assessment."
  },
  communication: {
    title: "Communication gaps",
    intro: "You deserve to understand hospital processes and know whom to ask.",
    steps: ["Ask the staff member who is responsible for your current question or process.", "Explain what you need in one short sentence and ask them to repeat important instructions.", "Request a language interpreter or trusted support person if available and appropriate.", "If the concern remains unresolved, ask for the patient-relations or grievance desk."],
    tip: "For medical decisions or treatment instructions, confirm details with a qualified clinician rather than relying on this website."
  },
  medicine: {
    title: "Medicine availability",
    intro: "If a prescribed medicine is unavailable, ask a pharmacist or prescriber about safe next steps.",
    steps: ["Ask the hospital pharmacist whether the medicine is temporarily out of stock and when it may be available.", "Ask the prescribing clinician or pharmacist whether an appropriate alternative is suitable for you.", "Use only a replacement approved by a qualified healthcare professional.", "If you need the medicine urgently, explain the situation to the clinical team promptly."],
    tip: "Do not stop, change, or substitute a prescribed medicine on your own."
  }
};

const dialog = document.getElementById("solutionDialog");
const dialogTitle = document.getElementById("dialogTitle");
const dialogIntro = document.getElementById("dialogIntro");
const dialogSteps = document.getElementById("dialogSteps");
const dialogTip = document.getElementById("dialogTip");

document.querySelectorAll("[data-open]").forEach(button => {
  button.addEventListener("click", () => {
    const item = solutions[button.dataset.open];
    if (!item) return;
    dialogTitle.textContent = item.title;
    dialogIntro.textContent = item.intro;
    dialogSteps.replaceChildren();
    item.steps.forEach(step => {
      const li = document.createElement("li");
      li.textContent = step;
      dialogSteps.appendChild(li);
    });
    dialogTip.textContent = item.tip;
    dialog.showModal();
  });
});

function closeDialog() { if (dialog.open) dialog.close(); }
document.getElementById("dialogClose").addEventListener("click", closeDialog);
document.getElementById("dialogDone").addEventListener("click", closeDialog);
dialog.addEventListener("click", event => {
  if (event.target === dialog) closeDialog();
});

const searchInput = document.getElementById("searchInput");
const filters = [...document.querySelectorAll(".filter")];
const cards = [...document.querySelectorAll(".problem-card")];
const emptyState = document.getElementById("emptyState");
let activeFilter = "all";

function filterCards() {
  const query = searchInput.value.trim().toLowerCase();
  let visible = 0;
  cards.forEach(card => {
    const categoryMatch = activeFilter === "all" || card.dataset.category === activeFilter;
    const searchMatch = (card.dataset.search + " " + card.innerText).toLowerCase().includes(query);
    const show = categoryMatch && searchMatch;
    card.hidden = !show;
    if (show) visible++;
  });
  emptyState.hidden = visible !== 0;
}
filters.forEach(button => button.addEventListener("click", () => {
  activeFilter = button.dataset.filter;
  filters.forEach(item => item.classList.toggle("active", item === button));
  filterCards();
}));
searchInput.addEventListener("input", filterCards);

const issueDetails = document.getElementById("issueDetails");
const charCount = document.getElementById("charCount");
issueDetails.addEventListener("input", () => charCount.textContent = issueDetails.value.length);

document.getElementById("reportForm").addEventListener("submit", event => {
  event.preventDefault();
  const issueType = document.getElementById("issueType").value;
  const details = issueDetails.value.trim();
  const message = document.getElementById("formMessage");
  if (!issueType || !details) {
    message.textContent = "Please select an issue and describe it before submitting.";
    return;
  }
  message.textContent = "Thank you. Your demo feedback has been recorded on this page only. It has not been sent to a hospital.";
  event.target.reset();
  charCount.textContent = "0";
});
